package testcases;

import org.testng.annotations.Test;

import pages.FdCalculatorPage;
import pages.Home;
import utility.Wrapperclass;

import org.testng.annotations.BeforeClass;

import java.awt.AWTException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;

public class IciciTestCase extends Wrapperclass {
	WebDriver driver;
	
	FdCalculatorPage fdcalculator ;
	
	Home home;
 
  @BeforeClass
  public void launchBrowser() throws InterruptedException {
	  
	  driver= launchBrowser("Chrome","https://www.icicibank.com/calculators/fd-calculator.html");
  }
  
  
  
  @Test
  public void testCase() throws AWTException {
	  fdcalculator = new  FdCalculatorPage(driver);
	  
	  home = new Home(driver);
	  
	//  fdcalculator.selectTypeOfFixedDeposit();
	  
	  fdcalculator.amountOfDeposit();
	  
	  fdcalculator.clickAnywhere();
	  
	  String value= fdcalculator.getMaturityValue();
	  System.out.println(value);
	  
	  
	  String interest=fdcalculator.getAggregateInterest();
	  System.out.println(interest);
	  
	  
	  fdcalculator.selectTenure();
	  
	  fdcalculator.tenureDays();
	  
	  
      fdcalculator.clickAnywhere();
	  
	  String value1= fdcalculator.getMaturityValue();
	  System.out.println(value);
	  
	  
	  String interest1=fdcalculator.getAggregateInterest();
	  System.out.println(interest);
	  
	  home.logoClick();
	  
	  takeScreenShot();
	  
	  
	  
	  
	  
	  
	  
  }

  @AfterClass
  public void closingBrowser() {
	  driver.close();
	  
  }

}
